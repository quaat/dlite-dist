dlite -- example 5d
=============================================================

Build an example to use dlite and TQ with C language. The goal is to build a table.

## Build and run on Microsoft Windows

The build with Cmake is not working so the visual studio project is provided.
In addition one should also have tq-win-x64-2019.1.17944-86.lib in the root directory for ex5d 

The database GES file is in the build folder as well as the PhilibTable.json file defining the entity.

hdf5_D.dll should also be accessible.