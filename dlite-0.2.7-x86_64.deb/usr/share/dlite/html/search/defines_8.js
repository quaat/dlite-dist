var searchData=
[
  ['unused_1411',['UNUSED',['../dlite-macros_8h.html#a86d500a34c624c2cae56bc25a31b12f3',1,'dlite-macros.h']]],
  ['uuid_5flen_1412',['UUID_LEN',['../getuuid_8h.html#a9692a0205a857ed2cc29558470c2ed77',1,'getuuid.h']]]
];
