var searchData=
[
  ['some_20general_20utility_20functions_1426',['Some general utility functions',['../md_src_utils_README.html',1,'']]]
];
