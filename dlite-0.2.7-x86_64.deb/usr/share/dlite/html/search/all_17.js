var searchData=
[
  ['xml_712',['XML',['../triplestore_8h.html#abe1454aa88ed04398388ff9d4148c490',1,'triplestore.h']]]
];
