var searchData=
[
  ['plugin_2eh_784',['plugin.h',['../plugin_8h.html',1,'']]]
];
