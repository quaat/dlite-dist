var searchData=
[
  ['getdataname_1180',['getDataName',['../struct__DLiteStoragePlugin.html#ab5a2cf5ef315ef2d824ae12d013d790a',1,'_DLiteStoragePlugin']]],
  ['getdimensionsize_1181',['getDimensionSize',['../struct__DLiteStoragePlugin.html#acb3033323b05b71b9a874812924b69d2',1,'_DLiteStoragePlugin']]],
  ['getmetauri_1182',['getMetaURI',['../struct__DLiteStoragePlugin.html#aafe5a4666271d80d69f1b7e7083920b1',1,'_DLiteStoragePlugin']]],
  ['getproperty_1183',['getProperty',['../struct__DLiteStoragePlugin.html#a48bb7ed5b1506fa4061bd8de1c226a4b',1,'_DLiteStoragePlugin']]],
  ['getuuids_1184',['getUUIDs',['../struct__DLiteStoragePlugin.html#a3ea9fffb2798f31b63016e09d73355d6',1,'_DLiteStoragePlugin']]]
];
