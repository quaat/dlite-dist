var searchData=
[
  ['resolvedimensions_1308',['ResolveDimensions',['../dlite-storage-plugins_8h.html#a51adf8d76555acc880c0acbc81a1cd6a',1,'dlite-storage-plugins.h']]]
];
