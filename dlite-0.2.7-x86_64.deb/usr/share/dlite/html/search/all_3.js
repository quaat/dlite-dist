var searchData=
[
  ['c_46',['c',['../struct__DLiteOpt.html#a396b0f0c02a994aaae5c464926f6c140',1,'_DLiteOpt']]],
  ['close_47',['close',['../struct__DLiteStoragePlugin.html#ace0ddf5e419b459ab99b2bb9c8af7e11',1,'_DLiteStoragePlugin']]],
  ['close_48',['Close',['../dlite-storage-plugins_8h.html#a36fd64ad78aaaa9258dd31520c3ffeee',1,'dlite-storage-plugins.h']]],
  ['compat_2eh_49',['compat.h',['../compat_8h.html',1,'']]],
  ['concepts_50',['Concepts',['../md_doc_concepts.html',1,'']]],
  ['context_51',['Context',['../structContext.html',1,'']]],
  ['cost_52',['cost',['../struct__DLiteMappingPlugin.html#a09dae537d26e0b00eb6be76e76197f9f',1,'_DLiteMappingPlugin::cost()'],['../struct__DLiteMapping.html#a15a93880d2151c517bc36f1d967a4da3',1,'_DLiteMapping::cost()']]],
  ['countof_53',['countof',['../dlite-macros_8h.html#ad95c8ecaa04eb417c1ddd2e7cee88053',1,'dlite-macros.h']]]
];
