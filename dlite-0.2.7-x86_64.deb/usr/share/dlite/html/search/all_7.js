var searchData=
[
  ['getdataname_470',['getDataName',['../struct__DLiteStoragePlugin.html#ab5a2cf5ef315ef2d824ae12d013d790a',1,'_DLiteStoragePlugin']]],
  ['getdataname_471',['GetDataName',['../dlite-storage-plugins_8h.html#a240ffd9ee65af67241bb7b9ed4897f41',1,'dlite-storage-plugins.h']]],
  ['getdimensionsize_472',['getDimensionSize',['../struct__DLiteStoragePlugin.html#acb3033323b05b71b9a874812924b69d2',1,'_DLiteStoragePlugin']]],
  ['getdimensionsize_473',['GetDimensionSize',['../dlite-storage-plugins_8h.html#ad912b1d98cbad5c1e796fe91c8bc6203',1,'dlite-storage-plugins.h']]],
  ['getdlitemappingapi_474',['GetDLiteMappingAPI',['../dlite-mapping-plugins_8h.html#adeb6ddecba66faa9dd7c31c38b0fb67d',1,'dlite-mapping-plugins.h']]],
  ['getdlitestorageapi_475',['GetDLiteStorageAPI',['../dlite-storage-plugins_8h.html#a2168d5be4b0b631b67b9645ee4e415cf',1,'dlite-storage-plugins.h']]],
  ['getmetauri_476',['getMetaURI',['../struct__DLiteStoragePlugin.html#aafe5a4666271d80d69f1b7e7083920b1',1,'_DLiteStoragePlugin']]],
  ['getmetauri_477',['GetMetaURI',['../dlite-storage-plugins_8h.html#a3f13be40e1c0265fdb834a75ee1ec99a',1,'dlite-storage-plugins.h']]],
  ['getproperty_478',['getProperty',['../struct__DLiteStoragePlugin.html#a48bb7ed5b1506fa4061bd8de1c226a4b',1,'_DLiteStoragePlugin']]],
  ['getproperty_479',['GetProperty',['../dlite-storage-plugins_8h.html#a69cb437acb0e5c3f8553250571918429',1,'dlite-storage-plugins.h']]],
  ['getuuid_480',['getuuid',['../getuuid_8h.html#abc39fb35a7ff6cadf61c3cd3ba3d0963',1,'getuuid.c']]],
  ['getuuid_2eh_481',['getuuid.h',['../getuuid_8h.html',1,'']]],
  ['getuuids_482',['getUUIDs',['../struct__DLiteStoragePlugin.html#a3ea9fffb2798f31b63016e09d73355d6',1,'_DLiteStoragePlugin']]],
  ['getuuids_483',['GetUUIDs',['../dlite-storage-plugins_8h.html#a1d322913535227f473b0fce18b8fa027',1,'dlite-storage-plugins.h']]],
  ['globmatch_2eh_484',['globmatch.h',['../globmatch_8h.html',1,'']]]
];
