var searchData=
[
  ['mapper_1301',['Mapper',['../dlite-mapping-plugins_8h.html#a0e36376ca291a3ffe71ca2461d96a778',1,'dlite-mapping-plugins.h']]]
];
