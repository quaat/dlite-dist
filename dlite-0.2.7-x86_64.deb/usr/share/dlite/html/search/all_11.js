var searchData=
[
  ['relations_578',['relations',['../struct__DLiteCollection.html#a9b8ffd7e5a78f4e1d3c7edcf3cf4a951',1,'_DLiteCollection']]],
  ['repl_579',['repl',['../struct__TGenSub.html#a52ac8a40e6ec27ae065d423954156f2d',1,'_TGenSub']]],
  ['reraise_580',['reraise',['../structErrRecord.html#a17a478c696d003cb55f5b614dfc8f857',1,'ErrRecord']]],
  ['resolvedimensions_581',['resolveDimensions',['../struct__DLiteStoragePlugin.html#aeb5befea71f39f2930c6ac74a5ecbd7c',1,'_DLiteStoragePlugin']]],
  ['resolvedimensions_582',['ResolveDimensions',['../dlite-storage-plugins_8h.html#a51adf8d76555acc880c0acbc81a1cd6a',1,'dlite-storage-plugins.h']]],
  ['rstore_583',['rstore',['../struct__DLiteCollection.html#a9aadac03df1e7ae3f428524971e85531',1,'_DLiteCollection']]]
];
