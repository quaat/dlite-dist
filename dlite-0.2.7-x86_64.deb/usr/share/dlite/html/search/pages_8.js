var searchData=
[
  ['the_20python_20storage_20plugin_1427',['The Python storage plugin',['../md_storages_python_README.html',1,'']]]
];
