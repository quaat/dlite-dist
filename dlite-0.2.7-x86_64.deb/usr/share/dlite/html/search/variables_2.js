var searchData=
[
  ['c_1164',['c',['../struct__DLiteOpt.html#a396b0f0c02a994aaae5c464926f6c140',1,'_DLiteOpt']]],
  ['close_1165',['close',['../struct__DLiteStoragePlugin.html#ace0ddf5e419b459ab99b2bb9c8af7e11',1,'_DLiteStoragePlugin']]],
  ['cost_1166',['cost',['../struct__DLiteMappingPlugin.html#a09dae537d26e0b00eb6be76e76197f9f',1,'_DLiteMappingPlugin::cost()'],['../struct__DLiteMapping.html#a15a93880d2151c517bc36f1d967a4da3',1,'_DLiteMapping::cost()']]]
];
