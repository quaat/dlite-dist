var searchData=
[
  ['map_5ft_1080',['map_t',['../plugin_8h.html#a369d4b2b871fd3c460f0e4db8acd63c1',1,'plugin.h']]]
];
