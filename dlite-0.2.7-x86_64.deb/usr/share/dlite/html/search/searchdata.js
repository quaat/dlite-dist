var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwx",
  1: "_cdeijmostuv",
  2: "cdefgimpst",
  3: "_adefgimpst",
  4: "abcdefghiklmnoprstuv",
  5: "cdefghilmoprst",
  6: "_",
  7: "dft",
  8: "acdefmpsuvwx",
  9: "bcdefmpst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

