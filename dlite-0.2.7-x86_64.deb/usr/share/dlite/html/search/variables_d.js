var searchData=
[
  ['o_1213',['o',['../struct__Triple.html#a4f39479207e72e92563850574bff5517',1,'_Triple']]],
  ['open_1214',['open',['../struct__DLiteStoragePlugin.html#ac33cda950da26973acb13bb4db9ab0cc',1,'_DLiteStoragePlugin']]],
  ['output_5furi_1215',['output_uri',['../struct__DLiteMappingPlugin.html#aadba852b4835e843d824e5e12778ab7f',1,'_DLiteMappingPlugin::output_uri()'],['../struct__DLiteMapping.html#a50fd0897162e38061aa712cfab3ef272',1,'_DLiteMapping::output_uri()']]]
];
