var searchData=
[
  ['saveinstance_1309',['SaveInstance',['../dlite-storage-plugins_8h.html#a7b3f36c6d3633fc6396bae218c067c70',1,'dlite-storage-plugins.h']]],
  ['setdataname_1310',['SetDataName',['../dlite-storage-plugins_8h.html#a4a5d33a9fa39d5a6c885d94d6c4673a4',1,'dlite-storage-plugins.h']]],
  ['setdimensionsize_1311',['SetDimensionSize',['../dlite-storage-plugins_8h.html#a2e4b160c372df6b0c4e22cf376ff765d',1,'dlite-storage-plugins.h']]],
  ['setmetauri_1312',['SetMetaURI',['../dlite-storage-plugins_8h.html#a61dc2089334e1ac997b3859a7fbf28af',1,'dlite-storage-plugins.h']]],
  ['setproperty_1313',['SetProperty',['../dlite-storage-plugins_8h.html#af496c3d693fd28cfc07e32be3494aa1e',1,'dlite-storage-plugins.h']]]
];
