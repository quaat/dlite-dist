var searchData=
[
  ['o_541',['o',['../struct__Triple.html#a4f39479207e72e92563850574bff5517',1,'_Triple']]],
  ['open_542',['open',['../struct__DLiteStoragePlugin.html#ac33cda950da26973acb13bb4db9ab0cc',1,'_DLiteStoragePlugin']]],
  ['open_543',['Open',['../dlite-storage-plugins_8h.html#a35fdb7cb1c5d830606554cbaa68e41c7',1,'dlite-storage-plugins.h']]],
  ['opinfo_544',['OpInfo',['../structOpInfo.html',1,'']]],
  ['output_5furi_545',['output_uri',['../struct__DLiteMappingPlugin.html#aadba852b4835e843d824e5e12778ab7f',1,'_DLiteMappingPlugin::output_uri()'],['../struct__DLiteMapping.html#a50fd0897162e38061aa712cfab3ef272',1,'_DLiteMapping::output_uri()']]]
];
