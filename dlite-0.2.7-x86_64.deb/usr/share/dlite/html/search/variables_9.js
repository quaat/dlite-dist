var searchData=
[
  ['key_1196',['key',['../struct__DLiteOpt.html#a3564a2c62b5b4210fc8f78ea731b8dbe',1,'_DLiteOpt']]],
  ['kind_1197',['kind',['../struct__PluginInfo.html#a9f45b28b579dcf757eb8c846dd2fb0de',1,'_PluginInfo']]]
];
