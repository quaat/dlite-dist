var searchData=
[
  ['close_1251',['Close',['../dlite-storage-plugins_8h.html#a36fd64ad78aaaa9258dd31520c3ffeee',1,'dlite-storage-plugins.h']]]
];
