var searchData=
[
  ['open_1302',['Open',['../dlite-storage-plugins_8h.html#a35fdb7cb1c5d830606554cbaa68e41c7',1,'dlite-storage-plugins.h']]]
];
