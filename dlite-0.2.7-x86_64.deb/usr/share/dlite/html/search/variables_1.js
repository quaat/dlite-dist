var searchData=
[
  ['buf_1163',['buf',['../struct__TGenBuf.html#a43e40162c05a3c804c0bdc8dad613ba7',1,'_TGenBuf']]]
];
