var searchData=
[
  ['data_1167',['data',['../struct__DLiteArray.html#aa61b424988f12ef76a790461a4b14e8f',1,'_DLiteArray::data()'],['../struct__DLiteMappingPlugin.html#aea656b2b9fd2007791a3fe40f393851f',1,'_DLiteMappingPlugin::data()'],['../struct__DLiteStoragePlugin.html#aebd41c15f21d4f86211b1e35f1333900',1,'_DLiteStoragePlugin::data()'],['../struct__TripleState.html#ae621cdf14ff309827b5cfe371ee12863',1,'_TripleState::data()']]],
  ['datamodel_1168',['dataModel',['../struct__DLiteStoragePlugin.html#abdf4737983e06e7ce1f4721d92fa6567',1,'_DLiteStoragePlugin']]],
  ['datamodelfree_1169',['dataModelFree',['../struct__DLiteStoragePlugin.html#ab69dd4bc4ab77354d032f87addd78a56',1,'_DLiteStoragePlugin']]],
  ['descr_1170',['descr',['../struct__DLiteOpt.html#a8b723a7e32c7b17d2e36037903cfa958',1,'_DLiteOpt']]],
  ['description_1171',['description',['../struct__DLiteDimension.html#ae93416998bc3bdd7b08d16cc3047221c',1,'_DLiteDimension::description()'],['../struct__DLiteProperty.html#a2db9ebc5af6096d5fd9f8661e01182eb',1,'_DLiteProperty::description()']]],
  ['dims_1172',['dims',['../struct__DLiteArray.html#ac18970070115855db9b90408053f8efe',1,'_DLiteArray::dims()'],['../struct__DLiteProperty.html#a2ccb7d1573a0f9d5258982f93ff8eafc',1,'_DLiteProperty::dims()']]],
  ['dlite_5fcodegen_5fuse_5fnative_5ftypenames_1173',['dlite_codegen_use_native_typenames',['../dlite-codegen_8h.html#a52fa06937c65a4db5089c76ec1fc16aa',1,'dlite-codegen.c']]]
];
