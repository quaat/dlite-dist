var searchData=
[
  ['buf_44',['buf',['../struct__TGenBuf.html#a43e40162c05a3c804c0bdc8dad613ba7',1,'_TGenBuf']]],
  ['build_20with_20visual_20studio_45',['Build with Visual Studio',['../md_doc_build_with_vs.html',1,'']]]
];
