var searchData=
[
  ['getdataname_1288',['GetDataName',['../dlite-storage-plugins_8h.html#a240ffd9ee65af67241bb7b9ed4897f41',1,'dlite-storage-plugins.h']]],
  ['getdimensionsize_1289',['GetDimensionSize',['../dlite-storage-plugins_8h.html#ad912b1d98cbad5c1e796fe91c8bc6203',1,'dlite-storage-plugins.h']]],
  ['getdlitemappingapi_1290',['GetDLiteMappingAPI',['../dlite-mapping-plugins_8h.html#adeb6ddecba66faa9dd7c31c38b0fb67d',1,'dlite-mapping-plugins.h']]],
  ['getdlitestorageapi_1291',['GetDLiteStorageAPI',['../dlite-storage-plugins_8h.html#a2168d5be4b0b631b67b9645ee4e415cf',1,'dlite-storage-plugins.h']]],
  ['getmetauri_1292',['GetMetaURI',['../dlite-storage-plugins_8h.html#a3f13be40e1c0265fdb834a75ee1ec99a',1,'dlite-storage-plugins.h']]],
  ['getproperty_1293',['GetProperty',['../dlite-storage-plugins_8h.html#a69cb437acb0e5c3f8553250571918429',1,'dlite-storage-plugins.h']]],
  ['getuuids_1294',['GetUUIDs',['../dlite-storage-plugins_8h.html#a1d322913535227f473b0fce18b8fa027',1,'dlite-storage-plugins.h']]]
];
